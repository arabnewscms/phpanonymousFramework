<?php
namespace framework;

class Views {

	protected static $path_folder = 'Views';
	private static  $ext = '.tpl.php';

	public static function make($pathview,$args = [])
	{

		extract($args);

		include self::$path_folder.'/'.$pathview.self::$ext;
	}


}