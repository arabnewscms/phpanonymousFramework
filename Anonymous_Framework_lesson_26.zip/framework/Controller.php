<?php 
namespace framework;

class Controller{
 
 public $path_controller = 'Controllers';





}