<?php 
namespace framework;

class Models{

public $path_models = 'Models';



}