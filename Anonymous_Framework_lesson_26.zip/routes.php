<?php 
use framework\Route;

Route::get('/','HomeController@index');
Route::get('user','HomeController@user');