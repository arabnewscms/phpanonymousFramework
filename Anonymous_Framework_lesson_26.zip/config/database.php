<?php 
	$InfoDataBase = [
			'dbname'=>'oop',
			'dbuser'=>'root',
			'dbpass'=>'root',
			'FETCH_TYPE'=>'object', // assoc , object
		];
