<?php 
//*****************************************************/
//                                                    */
//  Framework v 0.1 Aravel Created By PHP Anonymous   */
//  Free Source And You Can Use It  I'ts Open Source  */
//   Website: phpanonymous.com                        */
//   Email Address: gm@phpanonymous.com               */
//   If You Want Any Help You can Get with my group   */
//   On Facebook:                                     */
//				 fb.com/groups/anonymouses.developers */
//   Regards  :)                                      */
//*****************************************************/

use framework\Route;


Route::get('/','HomeController@index');
Route::get('user/{id}/{username}/{email}','HomeController@getuserbyid');
 