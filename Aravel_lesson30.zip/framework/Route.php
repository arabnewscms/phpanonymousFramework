<?php 
//*****************************************************/
//                                                    */
//  Framework v 0.1 Aravel Created By PHP Anonymous   */
//  Free Source And You Can Use It  I'ts Open Source  */
//   Website: phpanonymous.com                        */
//   Email Address: gm@phpanonymous.com               */
//   If You Want Any Help You can Get with my group   */
//   On Facebook:                                     */
//				 fb.com/groups/anonymouses.developers */
//   Regards  :)                                      */
//*****************************************************/
namespace framework;
 
class Route {
	public static $extract = [];
    public static $path_controller = 'Controllers';
	public static $route = ''; 

	public function __construct()
	{	
	 
	}
 
	public static function get($link,$controller)
	{
		$uri        = $_SERVER['REQUEST_URI'];
		$scriptname = str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
 		$get_link   = @Route::check_uri($uri,$scriptname.$link);

	    if(isset($get_link['status']) and $get_link['status'] == true 
	    	    and $get_link['final_link'] == $uri)
	    {
	      if(!empty($get_link['param']) and count($get_link['param']) > 0)
	      {
		   return Route::handel($controller,$get_link['param']);
	      }else{
	       return Route::handel($controller);
	      }
	    }
	}

	public static function handel($controller,$param=null)
	{
		  $extract = explode('@',$controller);	
		  if(file_exists(self::$path_controller.'/'.$extract[0].'.php'))
		  {
		  	include self::$path_controller.'/'.$extract[0].'.php';
		  	if($param != null)
		  	{		
 			  return	call_user_func_array(['Controllers\\'.$extract[0],$extract[1]],$param);	
		  	}else{
		  	  return	call_user_func(['Controllers\\'.$extract[0],$extract[1]]);		
		  	}
		  }
	}


	public static function check_uri($URI,$Link)
	{

		if(preg_match('/{|}/i', $Link))
		{
					$extract_pure = explode('/', $URI);
					$link = explode('/', $Link);
					$final = '';
					$i = 0;
					$param = [];

					foreach($link as $new)
					{
						 
							if(!preg_match('/{|}/i', $new))
							{
								$final .= '/'.$new;
							}else{
								array_push($param,$extract_pure[$i]);
								$final .= '/'.$extract_pure[$i]; 	
							}
						  $i++;	
					 
					}
			$final_link = str_replace('//','/', $final);
			return ['status'=>true,'param'=>$param,'final_link'=>$final_link];
		}else{
			if($URI == str_replace('//','/', $Link))
			{
				return ['status'=>true,'param'=>[],'final_link'=>str_replace('//','/', $Link)];		
			}
		}

	}
	 
}