<?php 
namespace Controllers;

use framework\Controller;
use framework\Views;

class HomeController extends Controller{

	public function index()
	{
		return Views::make('home',['title'=>'Title Home Page','message'=>'Welcome To Controller And Function Index']);
	}
 	
 	public function getuserbyid($id,$name,$email)
 	{
 		return Views::make('test',['id'=>$id,'name'=>$name,'email'=>$email]);
 	}

}