<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 <div style="background-color:#c33;color:#fff;">
 	Hi Mr = <?php echo $name; ?><br>
 	Your Id =<?php echo $id; ?><br>
 	Your Email  = <?php echo $email; ?>
 </div>
</body>
</html>