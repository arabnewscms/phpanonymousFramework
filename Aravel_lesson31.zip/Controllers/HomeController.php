<?php 
namespace Controllers;

use framework\Controller;
use framework\Views;
use framework\Models;
//use framework\User;
use framework\Request;

class HomeController extends Controller{

	public function index()
	{
		$testrequest = Request::get('test');
		return Views::make('home',['title'=>'Title Home Page','message'=>'Welcome To Controller And Function Index','test'=>$testrequest]);
	}
 	
 	public function getuserbyid($id,$name,$email)
 	{
 		return Views::make('test',['id'=>$id,'name'=>$name,'email'=>$email]);
 	}

 	public function result()
 	{
 		echo Request::post('username');
 	}
}