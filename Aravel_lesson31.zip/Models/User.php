<?php
namespace Models;
use framework\Models;

class User extends Models{
 public static $table = 'user';
 

}