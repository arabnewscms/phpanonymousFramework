<?php 
//*****************************************************/
//                                                    */
//  Framework v 0.1 Aravel Created By PHP Anonymous   */
//  Free Source And You Can Use It  I'ts Open Source  */
//   Website: phpanonymous.com                        */
//   Email Address: gm@phpanonymous.com               */
//   If You Want Any Help You can Get with my group   */
//   On Facebook:                                     */
//				 fb.com/groups/anonymouses.developers */
//   Regards  :)                                      */
//*****************************************************/
namespace framework;

class Errors {
	 
	public function __construct($dataException=null)
	{ 	 
		if(!empty($dataException))
		{
	    	self::view($dataException);		
		}
	} 
	
	public static function view($error)
	{
		include 'framework/errorpage.php'; 
	} 

}
