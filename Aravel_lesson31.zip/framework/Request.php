<?php 
namespace framework;

class Request {

	public static function get($get,$arra = [])
	{
		if(isset($_GET[$get]))
	 	{
	    	return $_GET[$get];	
		}
	}

	public static function post($get,$arra = [])
	{
		if(isset($_POST[$get]))
	 	{
	    	return $_POST[$get];	
		}
	}

	


}