<!DOCTYPE html>
<html>
<head>
	<title><?php echo $error; ?></title>
</head>
<body style="background:#f6f6f6">
  <center>
  <div style="width:80%;background-color:#f1f1f1;color:#000;min-height:500px;border:1px solid #000;">
  <pre>
  	<?php  echo $error; ?>
  </pre>
  </div>
  </center>
</body>
</html>