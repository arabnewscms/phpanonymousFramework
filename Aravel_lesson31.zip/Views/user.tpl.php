<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title; ?></title>
</head>
<body>
<div style="background-color:#c33;color:#fff;">
<?php  echo $getuser->name; ?><br>	
<?php  echo $getuser->email; ?><br>
<?php  echo $getuser->mobile; ?><br>	
<?php echo $message; ?>
</div>
</body>
</html>