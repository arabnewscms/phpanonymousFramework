<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title; ?></title>
</head>
<body>
<div style="background-color:#c33;color:#fff;">

<?php echo $message; ?>
<br>
 

 <form method="post" action="result">
 		<input type="text" name="username" >
 		<input type="submit" value="Send Username" />
 </form>

</div>
</body>
</html>