<?php 
use framework\Route;


Route::get('','HomeController@index');
Route::get('user','HomeController@allusers');
Route::get('admins','HomeController@admins');
Route::get('offers','HomeController@offers');
 