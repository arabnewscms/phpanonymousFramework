<?php 
require_once __DIR__.'/framework/Run.php';
new framework\Run();