<?php 
namespace framework;
 
class Route {
	public static $extract = [];
    public static $path_controller = 'Controllers';
	public static $route = ''; //link

	public function __construct()
	{	
		//$route = $_SERVER['REQUEST_URI'];
	}
 
	public static function get($link,$controller)
	{
		$scriptname = str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
	 //   return var_dump($link);
	    if($_SERVER['REQUEST_URI'] == $scriptname.$link)
	    {
		  Route::handel($controller);
	    }
	}

	public static function handel($controller)
	{
		  $extract = explode('@',$controller);	
		  if(file_exists(self::$path_controller.'/'.$extract[0].'.php'))
		  {
		  	include self::$path_controller.'/'.$extract[0].'.php';
 			return	call_user_func(['Controllers\\'.$extract[0],$extract[1]]);
		  }
	}

	 
}