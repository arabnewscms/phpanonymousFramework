<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title; ?></title>
</head>
<body>
<div style="background-color:#c33;color:#fff;">
	
<?php echo $message; ?>
</div>
</body>
</html>