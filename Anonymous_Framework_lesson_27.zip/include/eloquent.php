<?php
namespace Eloquent;
use Errors\Error;

class eloquent{

	public function __construct()
	{
			include 'config/database.php';

			$dsn  = 'mysql:dbname='.$InfoDataBase['dbname'].';host=127.0.0.1';
			$user = $InfoDataBase['dbuser'];
			$password = $InfoDataBase['dbpass'];
			if(!empty($InfoDataBase['dbname']) && !empty($InfoDataBase['dbuser']) && !empty($InfoDataBase['dbpass']))
			{

				if($InfoDataBase['FETCH_TYPE'] == 'assoc')
				{
					$fetch = \PDO::FETCH_ASSOC;// $data['col']
				}elseif($InfoDataBase['FETCH_TYPE'] == 'object'){
					$fetch = \PDO::FETCH_OBJ; // $data->obj
				}else{
					$fetch = \PDO::FETCH_OBJ;
				}

				try {
				    $dbh = new \PDO($dsn, $user, $password,[\PDO::ATTR_DEFAULT_FETCH_MODE,$fetch]);
				} catch (\PDOException $e) {
				   new Error($e->getMessage());
				}	
			}
	}



	
}