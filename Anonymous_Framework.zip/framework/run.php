<?php
namespace framework; 
use Eloquent\eloquent;


class Run{

	public function __construct()
	{
		 require_once 'include/eloquent.php';
		 new eloquent();
	}

 }