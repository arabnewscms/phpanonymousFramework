 <?php 
 
 require_once __DIR__.'/framework/run.php';

 new framework\Run();