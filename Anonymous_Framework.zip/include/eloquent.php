<?php
namespace Eloquent;

class eloquent{

	public function __construct()
	{
			include 'config/database.php';
			$dsn = 'mysql:dbname='.$InfoDataBase['dbname'].';host=127.0.0.1';
			$user = $InfoDataBase['dbuser'];
			$password = $InfoDataBase['dbpass'];
			try {
			    $dbh = new \PDO($dsn, $user, $password);
			} catch (\PDOException $e) {
			    echo 'Connection failed: ' . $e->getMessage();
			}	
	}
}