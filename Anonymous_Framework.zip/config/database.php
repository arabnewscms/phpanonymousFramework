<?php 
	$InfoDataBase = [
			'dbname'=>'DATABASE',
			'dbuser'=>'UserNameDB',
			'dbpass'=>'Password',
		];
